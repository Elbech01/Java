/*Chris Elbe
elbecr@mail.uc.edu
I did not collaborate with anyone on this project*/
package weather;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.io.*;
import java.text.DecimalFormat;
import java.util.*;



public class Weather {

    
    public static void main(String[] args) {
       JFrame frame = new JFrame();
       frame.setSize(300, 400);
       frame.setTitle("Cincinnati Weather");
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
       JPanel panel = new JPanel();
       panel.setSize(300, 400);
       panel.setBackground(Color.BLACK);
       
       final JButton btnGet = new JButton("Cincinnati Weather: Feb 2019");
       btnGet.setForeground(Color.white);
       btnGet.setBackground(Color.blue);
       
       final JLabel label = new JLabel();
       label.setForeground(Color.white);
       label.setText("<html>February 2019 <br>Average Max T: <br>Average Min T: <br>Total Snow: </html>");
       
       panel.add(btnGet);
       panel.add(label);
       
       frame.add(panel);
       frame.setVisible(true);
       
       class GetWeatherButton implements ActionListener{
            public void actionPerformed(ActionEvent event) {
                
                try{
                    File inputFile = new File("feb19_cincinnati_weather.txt");
                    Scanner in = new Scanner(inputFile);
                    String line = "";
                    in.nextLine();
                    double max = 0;
                    double min = 0;
                    double snow = 0;
                    double avgMax = 0;
                    double avgMin = 0;
                    double days = 0;
                    DecimalFormat format = new DecimalFormat("#.00");
                    try{
                        while(in.hasNextLine())
                        {
                            line = in.nextLine();
                            String[] lineContent = line.split("\t");
                            max = max + Double.parseDouble(lineContent[1]);
                            min = min + Double.parseDouble(lineContent[2]);
                            days = days + 1;
                            if (lineContent[5].equals("T")){}
                            else
                            {
                                snow = snow + Double.parseDouble(lineContent[5]);
                            }
                            
                        }
                        avgMax = max / days;
                        avgMin = min / days;
                        
                        
                        label.setText("<html>February 2019 <br>Average Max T: " + format.format(avgMax) + "<br>Average Min T: " + format.format(avgMin) + "<br>Total Snow: " + format.format(snow) + "</html>");
                    }
                    finally{
                        in.close();
                    }
                    
                }
                catch(IOException e){
                    label.setText("Error opening file");
                    label.setForeground(Color.red);
                }
                catch(NumberFormatException n)
                {
                    System.out.println("Number format error");
                }
                
            }
            }
       ActionListener listener = new GetWeatherButton();
       btnGet.addActionListener(listener);
    }

}
