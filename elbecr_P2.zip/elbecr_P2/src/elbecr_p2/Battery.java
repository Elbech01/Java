package elbecr_p2;
public class Battery {
private double capacity;
private static double totalCapacity = 3000;

public Battery(){
    capacity = totalCapacity;
}

public double getCapacity(){
    return capacity;
}

public void drain(double amount){
    capacity = capacity - amount;
}

public void charge(){
    capacity = totalCapacity;
}
}