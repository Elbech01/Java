//Name: Chris Elbe
//Program: MonthlyMortgageCalculator
//Purpose: Calculate the monthly payment for a loan with a given Annual Percentage Rate and number of years
//Date: October 23rd, 2018
package monthlymortgagecalculator;

        import java.util.Scanner;       //Importing the scanner class
        import java.text.NumberFormat;


public class MonthlyMortgageCalculator {

    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);     //Creating an object of the scanner class
        NumberFormat normalFormat = NumberFormat.getCurrencyInstance();
        
        double amount;
        double rate;
        double monthlyRate;
        double annualRate;                  //Declaring variables
        double years;
        double months;
        double monthlyPayment;
        String askAgain = "y";
        
        while(askAgain.equals("y"))         //While loop to see if the condition is true
            {
                try
                 {
                    System.out.print("Enter loan amount: ");
                    amount = Double.parseDouble(input.nextLine());
                    System.out.print("Enter rate: ");
                    rate = Double.parseDouble(input.nextLine());            //Getting input from user
                    System.out.print("Enter number of years: ");
                    years = Double.parseDouble(input.nextLine());
   
                     if(amount > 0 && rate > 0 && years > 0)     //If statement to determine if data is positve
                {
                      months = years * 12;
                      annualRate = rate/100;                  //Calculating number of months, the annual rate, the monthly rate,
                      monthlyRate = annualRate/12;      //  and the monthly payments if the statement is true
                      monthlyPayment = monthlyRate  * amount * Math.pow(1 + monthlyRate, months)/(Math.pow(1+monthlyRate, months)-1);

                      System.out.println();
                      System.out.println("The monthly payment is: " + normalFormat.format(monthlyPayment));           //Displaying the "true" output
                      System.out.println();
                }
            else
                {
                      System.out.println();
                      System.out.println("You must enter positive numeric data!");        //DIsplaying the "false" output
                      System.out.println();
                }
        
                }
            catch(NumberFormatException e)
                {
                    System.out.println();
                    System.out.println("You must enter positive numeric data!");        //Displaying the caught error message
                    System.out.println();
                }
                    System.out.print("Would you like to calculate again? (y/n): ");
                    askAgain = input.nextLine();                                                            //Getting input for the while loop
                    System.out.println();
            }
    }

}