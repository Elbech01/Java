package FinalDrawingViewer;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;

public class FinalDrawingViewer extends JFrame{

    public static void main(String[] args) {
        //set up the frame
        JFrame frame = new JFrame();
        frame.setSize(300, 550);
        frame.setTitle("Drawing");  
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //create GUI objects
        final JButton button = new JButton("Show Chart!");
        final JButton button2 = new JButton("Clear Chart!");
      
        //create sliders
        final int colorMin = 0;
        final int colorInitial = 0;
        final int colorMax = 255;
        
        final JSlider redSlider = new JSlider(JSlider.HORIZONTAL, colorMin, colorMax, colorInitial);
        redSlider.setMajorTickSpacing(50);
        redSlider.setPaintTicks(true);
        redSlider.setPaintLabels(true);
        final JSlider greenSlider = new JSlider(JSlider.HORIZONTAL, colorMin, colorMax, colorInitial);
        greenSlider.setMajorTickSpacing(50);
        greenSlider.setPaintTicks(true);
        greenSlider.setPaintLabels(true);
        final JSlider blueSlider = new JSlider(JSlider.HORIZONTAL, colorMin, colorMax, colorInitial);
        blueSlider.setMajorTickSpacing(50);
        blueSlider.setPaintTicks(true);
        blueSlider.setPaintLabels(true);
        

        final JLabel redLabel = new JLabel("         Red        ");
        final JLabel greenLabel = new JLabel("       Green      ");
        final JLabel blueLabel = new JLabel("        Blue        ");
  
        //create the drawing object
        final FinalDrawingComponent chart = new FinalDrawingComponent();//polymorphism in action due to inheritance\
        //so that the chart appears on the panel, dimensions can be less than the frame size
        chart.setPreferredSize(new Dimension(250, 250));
              
  
        //create the panel and add all GUI and the chart
        JPanel panel = new JPanel();
        //add the grid to the frame
        panel.add(button);
        panel.add(button2);
        panel.add(redLabel);
        panel.add(redSlider);
        panel.add(greenLabel);
        panel.add(greenSlider);
        panel.add(blueLabel);
        panel.add(blueSlider);
        panel.add(chart);
        
        //add panel to the frame
        frame.add(panel);
        frame.setVisible(true);
        
        class ButtonListener implements ActionListener
        {
            public void actionPerformed(ActionEvent event)
            {   
               try{
                  File input = new File("drawing_data.txt");
                   Scanner in = new Scanner(input);
                   try{
                       //chart.changeColor();
		       in.nextLine();
                       while(in.hasNextLine()){
                        String line = in.nextLine();
                        String [] lineContent = line.split(" ");//data is split by a single space
                        chart.appendValues(Integer.parseInt(lineContent[0]),Integer.parseInt(lineContent[1]));
                       }
                    }
                   finally{
                       in.close();
                   }
                   
               } 
               catch(IOException e){
                   System.out.println("error file");
               }
               if (event.getSource() == button2){
                   chart.clearArray();
               }
            }
        }
        class SliderListener implements ChangeListener
        {
            public void stateChanged(ChangeEvent e){
                int red = redSlider.getValue();
                int green = greenSlider.getValue();
                int blue = blueSlider.getValue();
                chart.changeColor(red, green, blue);
            }
        }
       ActionListener listener1 = new ButtonListener();
       button.addActionListener(listener1);   
       button2.addActionListener(listener1);
       ChangeListener change = new SliderListener();
       redSlider.addChangeListener(change);
       greenSlider.addChangeListener(change);
       blueSlider.addChangeListener(change);
    }
}
