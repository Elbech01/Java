/*
  Chris Elbe
  elbecr@mail.uc.edu
  I did not collaborate with anyone on this project.  
*/
package elbecr_p2;


public class P2Tester {

    
    public static void main(String[] args) {
        Employee person = new Employee();
        System.out.println("Name: " + person.getName());
        System.out.println("Salary: " + person.getSalary());
        person.setName("Chris");
        person.setSalary(45000);
        System.out.println("Name: " + person.getName());
        System.out.println("Salary: " + person.getSalary());
        System.out.println();
        
        Balloon bal = new Balloon();
        System.out.println("Radius: " + bal.getRadius());
        System.out.println("Volume: " + bal.getVolume());
        bal.inflate(5);
        System.out.println("Radius: " + bal.getRadius());
        System.out.println("Volume: " + bal.getVolume());
        System.out.println();
        
        Battery bat = new Battery();
        System.out.println("Capacity: " + bat.getCapacity());
        bat.drain(500);
        System.out.println("Capacity: " + bat.getCapacity());
        bat.charge();
        System.out.println("Capacity: " + bat.getCapacity());
        System.out.println();
        
        Bug bugsy = new Bug(10); //starts at initial position 10
        bugsy.move(); // Now the position is 11
        bugsy.move(); // Now the position is 12
        System.out.println(bugsy.getPosition()); //should print 12
        bugsy.turn(); // Now the direction has changed
        bugsy.move(); // Now the position is 11
        System.out.println(bugsy.getPosition()); //should print 11
        System.out.println();
        
        Message message = new Message("Chris", "Bill");
        System.out.println(message.composeMessage());
        message.append("This is a test.");
        System.out.println(message.composeMessage());

    }

}
