package FinalDrawingViewer;

import java.awt.*;
import java.util.*;
import javax.swing.*;

public class FinalDrawingComponent extends JComponent {
   
    private ArrayList<Point> values;
       
   public FinalDrawingComponent(){
       values = new ArrayList<Point>();
   }
   
   public void appendValues(int x, int y){
       values.add(new Point(x,y));//add a new Point to draw
       repaint();//call paintcomponent to redraw
   }
   
   public void clearArray(){
       values.clear();
       repaint();
   }
   public void changeColor(int r, int g, int b){
    // int red = (int) (Math.random() * 256);
    // int green = (int) (Math.random() * 256);
    // int blue = (int) (Math.random() * 256); 
     this.setForeground(new Color(r,g,b));  
    clearArray();//this may be important to add later...can you tell why?
   }
   @Override
   public void paintComponent(Graphics g) {      
      
      g.fillRect(0, 0, getWidth(), getHeight());//drawing the background with the color set in changeColor
      
      for (int i=0; i< values.size(); i++){
          int x =  values.get(i).x;
          int y = values.get(i).y;
          int width = (int) (Math.random() * 50);
          int height = (int) (Math.random() * 50);
          int red = (int) (Math.random() * 255);
          int green = (int) (Math.random() * 255);
          int blue = (int) (Math.random() * 255);
          
          Color c = new Color(red,green,blue);
          g.setColor(c);          
          g.fillOval(x, y, width, height);
      }     
   }
}
