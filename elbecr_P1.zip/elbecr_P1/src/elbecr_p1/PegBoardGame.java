//Chris Elbe
//elbecr@mail.uc.edu
//I did not collaborate with anyone
package elbecr_p1;
import java.util.ArrayList;
import java.util.Scanner;

public class PegBoardGame {

    
    public static void main(String[] args) {
        ArrayList<Integer> pegboard = create_pegboard();//The method create_pegboard that takes no arguments is called, which creates an arraylist with 10 numbers, and returns the list. THat list is stored in the Arraylist pegboard variable.
        print_pegboard(pegboard);//The method print_pegboard that takes one argument of an Arraylist is called, this prints out the Arraylist in the console
        for (int i = 0; i < 10; i++) { //For loop that starts at 0 and increments by 1 each time it goes through, up until 10 times through
             peg_hole(pegboard);       //peg_hole method that takes an Arraylist argument is called and allows the user to peg a hole each time it goes through
             print_pegboard(pegboard); //print_pegboard method that takes an Arraylist argument is called, prints the new Arraylist after a hole has been pegged
        }

    }
    
    public static ArrayList create_pegboard()
    {
        ArrayList<Integer> pegboard = new ArrayList<Integer>();
        for (int i = 1; i <= 10; i++) {
            pegboard.add(i);
        }
        
        return pegboard;
    }
    
    public static void print_pegboard(ArrayList<Integer> pegboard) {
        System.out.println("--------------------------------");
        System.out.println(pegboard);
        System.out.println("--------------------------------");
    }
    
    public static void peg_hole(ArrayList<Integer> pegboard) {
        int peg;
        Scanner in = new Scanner(System.in);
        System.out.println("What hole would you like to peg?");
        peg = Integer.parseInt(in.nextLine());
        
        if (pegboard.get(peg - 1) == 0)
            System.out.println("Hole number " + peg + " has already been pegged.");
        else
            pegboard.set(peg - 1,0);
    }

}
