package elbecr_p2;


public class Message {
    private String recipient;
    private String sender;
    private String messageText;
    private static int numMessage;
    
    public Message(String s, String r){
        sender = s;
        recipient = r;
        messageText = "";
        numMessage++;
    }
    
    public void append(String text){
        messageText = messageText + text;
    }
    
    public String composeMessage(){
        return ("From: " + sender + "\nTo: " + recipient + "\nMessage: " + messageText);
    }
}