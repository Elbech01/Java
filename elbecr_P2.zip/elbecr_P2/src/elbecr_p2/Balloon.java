package elbecr_p2;


public class Balloon {
private double radius;

public Balloon(){
    radius = 0;
}

public void inflate(double amount){
    radius = radius + amount;
}
public double getRadius(){
    return radius;
}

public double getVolume(){
    return ((4/3) * Math.PI * (radius * radius * radius));    
}
}
