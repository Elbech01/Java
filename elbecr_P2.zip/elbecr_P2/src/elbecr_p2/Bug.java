package elbecr_p2;


public class Bug {
private int currentPosition;
private int direction;

public Bug(int initialPosition){
    currentPosition = initialPosition;
    direction = 1;
}

public int getPosition(){
    return currentPosition;
}

public void move(){
    currentPosition = currentPosition + direction;
}

public void turn(){
    direction = direction * (-1);
}
}