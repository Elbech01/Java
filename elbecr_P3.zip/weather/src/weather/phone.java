package weather;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.net.URL;
import java.util.Scanner;
import javax.swing.JTextField;



public class phone {

    
    public static void main(String[] args) {
       JFrame frame = new JFrame();
       frame.setSize(300, 400);
       frame.setTitle("Cincinnati Weather");
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
       JPanel panel = new JPanel();
       panel.setSize(300, 400);
       panel.setBackground(Color.BLACK);
       
       final JButton btnRetrieve = new JButton(" Get Country Phone Subscriber Count ");
       btnRetrieve.setForeground(Color.white);
       btnRetrieve.setBackground(Color.blue);
       final JButton btnCountry = new JButton("Search for a Country's Subscribers");
       btnCountry.setForeground(Color.white);
       btnCountry.setBackground(Color.blue);
       final JTextField txtCountry = new JTextField(20);
       txtCountry.setBackground(Color.white);
       txtCountry.setForeground(Color.black);
       
       
       final JLabel label = new JLabel("Subscribers");
       label.setForeground(Color.white);
       final JLabel label2 = new JLabel("Country");
       label2.setForeground(Color.white);
       
       panel.add(btnRetrieve);
       panel.add(label);
       panel.add(txtCountry);
       panel.add(btnCountry);
       panel.add(label2);
       
       frame.add(panel);
       frame.setVisible(true);
       
       class RetrieveButton implements ActionListener{
            @Override
            public void actionPerformed(ActionEvent event) {
                try{
                String address = "https://www.cia.gov/library/publications/the-world-factbook/rankorder/rawdata_2151.txt";
                URL pageLocation = new URL(address);
                String line = "";
                String[] labelS = {"","","","","","","","","",""};
                Scanner in = new Scanner(pageLocation.openStream());
                int count = 0;
                try{
                    while(count < 10){
                    
                      line = in.nextLine();
                      String[] lineContent = line.split("\\s+");
                      labelS[count] = lineContent[0] + ": " + lineContent[1] + " " + lineContent[2];
                      count++;
                }
                    label.setText("<html>" + labelS[0] + "<br>" + labelS[1] + "<br>" + labelS[2] + "<br>" + labelS[3] + " 395,881,000" + "<br>" + labelS[4] + "<br>" + labelS[5] + "<br>" + labelS[6] + "<br>" + labelS[7] + "<br>" + labelS[8] + "<br>" + labelS[9]);
                }
                finally{
                    in.close();
                }
                
                }
                
                catch(IOException e){
                    label.setText("Error");
                    label.setForeground(Color.red);
                    
                }
                catch(NumberFormatException n){
                    System.out.println("Error");   
                }
                
            }
       }   
       class CountryButton implements ActionListener{
            @Override
            public void actionPerformed(ActionEvent event) {
                try{
                String address = "https://www.cia.gov/library/publications/the-world-factbook/rankorder/rawdata_2151.txt";
                URL pageLocation = new URL(address);
                String line = "";
                Scanner in = new Scanner(pageLocation.openStream());
                while(in.hasNextLine()){
                    line = in.nextLine();
                    String[] lineContent = line.split("\\s+");
                    if(lineContent[1].equals(txtCountry.getText())){
                        label2.setText(lineContent[0] + ": " + lineContent[1] + " " + lineContent[2]);
                    }
                   
                }
                }
                catch(IOException e){
                    label2.setText("Error opening URL");
                }
            }
            }
       ActionListener listener = new RetrieveButton();
       ActionListener listener2 = new CountryButton();
       btnRetrieve.addActionListener(listener);
       btnCountry.addActionListener(listener2);
    }
}