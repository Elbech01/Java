package elbecr_p2;


public class Employee {
private String name;
private double salary;

public Employee(){
    name = "";
    salary = 0;
}

public void setName(String n){
    name = n;
}

public void setSalary(double s){
    salary = s;
}

public double getSalary(){
    return salary;
}

public String getName(){
    return name;
}
}
