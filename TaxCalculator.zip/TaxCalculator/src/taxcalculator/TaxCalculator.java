
package taxcalculator;

/**Author: Chris Elbe
 * Program Name: Tax Calculator
 * Date: September 25, 2018
 * Class: Computer Programming I
 */
import java.util.Scanner;
public class TaxCalculator {
   
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);     //Create scanner
        
        double salesPrice;
        double tax;             //Declare variables
        double total;
        
        System.out.println("Enter the amount of the sale.");    //Ask for input
        salesPrice = Double.parseDouble(input.nextLine());
        
        tax = salesPrice * .065;        //Calculations
        total = salesPrice + tax;
        
        System.out.printf("The tax is: $%.2f%n", tax);      //Showing the ouput
        System.out.printf("The total is: $%.2f%n", total);
        
    }
    
}
