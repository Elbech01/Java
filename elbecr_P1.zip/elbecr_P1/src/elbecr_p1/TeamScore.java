//Chris Elbe
//elbecr@mail.uc.edu
//I did not collaborate with anyone
package elbecr_p1;
public class TeamScore {

    public static boolean winner( int points1, int points2)
    {
        if (points1 > points2)
            return true;
        else
            return false;
        
    }
    public static void main(String[] args) {
        int team1Score;
        int team2Score;
        int team1Total = 0;
        int team2Total = 0;
        boolean winner;
        int[] team1 = {23,45,65,20};
        int[] team2 = {20,30,20,18};
        
        for (int i = 0; i < team1.length; i++) {
            team1Score = team1[i];
            team2Score = team2[i];
            winner = winner(team1Score,team2Score);
            if (winner)
                team1Total++;
            else
                team2Total++;
        }
        System.out.println("Team 1 Record");
        System.out.println("------------------");
        System.out.println("Win " + team1Total);
        System.out.println("Loss " + team2Total);
        
        if (team2Total == 0)
            System.out.println("Team 1 has a perfect record!");
    }
    
}
